if (screen.width <= 699) {
document.location = "http://m.partner.thetravelsquare.in";
}
