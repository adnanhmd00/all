function dynamicdropdown(listindex)
            {
                document.getElementById("subcategory").length = 0;
                switch (listindex)
                {
                    case "Abu" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("Cakephp","Cakephp");
                        break;
                    
                    case "Agartala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("Strauts","Strauts");
                        document.getElementById("subcategory").options[2]=new Option("Hibernate","Hibernate");
                        break;
                    case "Ahmedabad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("D-Jango","D-Jango");
                        break;
                    case "Aizawl" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ahmer" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Allahabad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Almora" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Along" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Alwar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Amarnath" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ambala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Amboli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Amritsar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Andaman" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Andhra Pradesh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Araku" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Arunachal Pradesh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Assam" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Auli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Aurangabad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Badrinath" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bagan" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bagdogra" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bakkhali" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bali" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bandhavgarh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bandipur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bangalore" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Banjar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Barot" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Batala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bhandardara" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bhangarh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bharatpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bhatinda" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bhimashankar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bhimtal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bihar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bikarner" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bir-Billing" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Bundi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chail" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chalakudy" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chamba" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Champawat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chandigarh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chattisgarh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Cherrapunji" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chikhaldara" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chikmagalur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chitkul" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chittorgarh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Chumathang" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Coimbatore" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Coonoor" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Coorg" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Corbett" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dadra & Nagar Haveli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dalhousie" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Daman" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Daman & Diu" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dandeli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Daranghati" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Darjeeling" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dehradun" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Delhi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Devprayag" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dhana" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dhanaulti" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dharamshala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dibrugarh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Digha" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dimapur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Diu" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dudhwa" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Dwarka" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Faridabad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "GHNP" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gangotri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gangtok" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gaya" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ghaziabad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gir" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Goa" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gokarna" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gopalpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gorakhpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gujarat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gulmarg" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Guntakal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Guptkashi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Gurdaspur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Guwahati" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Haflong" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Hampi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Hanoi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Haridwar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Haryana" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Himachal Pradesh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Hogenakkal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Hoshiarpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Hunder" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Igatpuri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Imphal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Indore" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Itanagar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jabalpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jagdalpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jaisalmer" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jakarta" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jalandhar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jammu & Kashmir" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jharkhand" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jodhpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Jorhat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Joshimath" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Junagadh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Junnar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kalimpong" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kamshet" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kanatal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kanchipuram" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kangra" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kanyakumari" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kargil" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Karjat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Karnaprayag" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Karnataka" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Karsog" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kasauli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kashid" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kasol" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Katra" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kaza" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kaziranga" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kedarnath" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kerala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Keylong" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Khajjiar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Khajuraho" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Khandala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kharapathar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Khimsar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break; 
                        case "Kochi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kodaikanal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kohima" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kolad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kollam" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Konark" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kota" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kovalam" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kozhikode" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kudremukha" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kufri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kullu" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kumarakom" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kumbhalgah" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kurnool" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kurseong" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kurukshetra" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Kutch" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lachung" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lakshadweep" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lamayuru" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lambasingi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lansdowne" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lavasa" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Leh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Likir" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lohajung" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lonar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Lucknow" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ludhiana" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Madhya Pradesh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Madurai" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mahabaleshwar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mahabalipuram" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Maharashtra" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Male" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Malvan" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Manali" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mndarmani" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mandi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mandu" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Manipur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Maredumilli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Matheran" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mathura" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mawlynnong" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mawsynram" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mcleodganj" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Meghalaya" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mizoram" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mohali" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mukteshwar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mumbai" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Munnar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mussoorie" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Mysore" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nagaland" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Naggar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nagpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nainital" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nandaprayag" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nandi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Narkanda" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nashik" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Naukuchiatal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Neemrana" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nelliyampathy" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Netarhat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Noida" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Nongstoin" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Odisah" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Orchha" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Osian" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pahalgam" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Palakkad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Palanpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Panchgani" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Panna" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pasighat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pathankot" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Patiala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Patna" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Patnitop" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pattaya" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Peermade" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pelling" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Periyar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pithoragarh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pondicherry" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pune" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Punjab" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Puri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Pushkar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Raipur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Rajaji" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Rajasthan" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Rajgir" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Rajkot" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Rameshwaram" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ramtek" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ranchi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ranikhet" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ranthambore" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ratnagiri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ravangla" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Rudraprayag" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sagar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Samui" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sanchi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sangli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Saputara" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sariska" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Seoni" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Shillong" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Shimla" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Shirdi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Shivanasamundram" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Shoghi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Shravanabelagola" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sikkim" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Silchar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Siliguri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Similipal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Singalila" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sirmaur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Solan" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sonamarg" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sonipat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Srinagar" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Sundarbans" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Surat" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tamenglong" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tamil Nadu" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tanakpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tarkarli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tatapani" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tawang" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Telangana" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tezpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Thanjavur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Thenmala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Thiruvananthapuram" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Thiruchirappalli" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tirupati" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tiruvannamalai" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tripura" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Tura" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Udaipur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ujjain" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Unakoti" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Uttar Pradesh" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Uttarakhand" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Uttarkashi" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Vadodara" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Vagamon" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Varkala" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Visakhapatnam" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Vishnuprayag" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Vrindavan" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Wayanad" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "West Bengal" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Yamunotri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Yelagiri" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Yousmarg" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Zirakpur" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;
                        case "Ziro" :
                        document.getElementById("subcategory").options[0]=new Option("Please select framework","");
                        document.getElementById("subcategory").options[1]=new Option("VbScript","VbScript");
                        break;


                }
                return true;
            }