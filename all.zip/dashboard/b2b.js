var app = angular.module('stay', ['angular.filter'])
    .config(['$interpolateProvider',"$locationProvider", function ($interpolateProvider, $locationProvider) {
        $interpolateProvider.startSymbol('[[');
        $interpolateProvider.endSymbol(']]');
        $locationProvider.html5Mode({
          enabled: true,
          requireBase: false
        });
    }])
.controller('myCtrl', function($scope){
    $scope.inc = 'popup-hotel.php';
})
    .controller('stayController', ["$scope", "$http", "$filter", "$location", function ($scope, $http, $filter, $location) {
        $scope.hotel = {};
        $scope.showSearchResult = false;
        $scope.resp = false;
        var searchKey = 'city';
        // $scope.hotel.ci = new Date();
            $scope.hotel.ci = new Date();
        // $scope.hotel.co = new Date();
            $scope.hotel.co = new Date();
    // }
        $scope.hotel.co.setDate($scope.hotel.co.getDate() + 1);

        

        

        $scope.result = function (data, status) {
            $scope.hotel.search = data;
            searchKey = status;
            // $scope.getHotel();
            $scope.showSearchResult = false;

        }

        $scope.show = function () {
            if ($scope.showSearchResult == false) {
                $scope.showSearchResult = true;
            }
            else {
                $scope.showSearchResult = false;
            }
        }


        var jsonToQueryString = function (json) {
            return '?' +
                Object.keys(json).map(function (key) {
                    if (json[key]) {
                        return encodeURIComponent(key) + '=' +
                            encodeURIComponent(json[key]);
                    } else {
                        return '';
                    }
                }).join('&');
        };


        $scope.getHotel = function () {
            // console.log("$location.path",$location.path);
            $scope.location = 'http://business.thetravelsquare.in/hotel';
            $scope.hotel.ci = Date.parse($scope.hotel.ci) / 1000;
            $scope.hotel.co = Date.parse($scope.hotel.co) / 1000;
            if (searchKey == 0) {
                $scope.message = 'enter valid location ';
            }
            console.log("hotel CI",$scope.hotel.ci);
            console.log("hotel CO",$scope.hotel.co);
            window.open($scope.location + "/list?" + searchKey + "=" + $scope.hotel.search + '&' + 'ci' + '=' + $scope.hotel.ci + '&' + 'co' + '=' + $scope.hotel.co, '_blank');
        };

        $scope.search = function () {
            $scope.hotel.search = $scope.hotel.search.toLowerCase();
            $http({
                method: 'POST',
                url: 'http://business.thetravelsquare.in/api/v1/hotel/search',
                data: $scope.hotel

            }).then(function successCallback(response) {
                $scope.cities = response.data.result.cities;
                $scope.names = response.data.result.names;
                if ($scope.cities.length == 0 && $scope.names.length != 0) {
                    searchKey = 'name';
                }
                if ($scope.cities.length != 0 && $scope.names.length == 0) {
                    searchKey = 'city';
                }
                if ($scope.cities.length != 0 && $scope.names.length != 0) {
                    searchKey = 'city';
                }
            })

        };

        $http({
            method: 'GET',
            url: 'http://business.thetravelsquare.in/api/v1/hotel/b2b'
        }).then(function successCallback(response) {
            $scope.hotels = response.data.result.hotel;
            for (var j = 0; j < $scope.hotels.length; j++) {
                $scope.hotelid[$scope.hotels[j].id] = $scope.hotels[j];
            }
            // this callback will be called asynchronously
            // when the response is available
        }, function errorCallback(response) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
        })


        //  }
    }])