var app = angular.module('testing', []);

app.controller('testCtrl', function($scope,$http){
$scope.test = {};

$scope.onSubmit = function(){
    console.log("Submitted");
    console.log($scope.test);

    $http.post('http://0.0.0.0:9000/api.php', $scope.test).success
};
});