$(document).ready(function () {
  $("#city").change(function () {
    var city_id = $(this).val();
    if (city_id != "") {
      $.ajax({
        url: "subcity.php",
        data: { c_id: city_id },
        type: 'POST',
        success: function (response) {
          var resp = $.trim(response);
          $("#groups").html(resp);
        }
      });
    }
  });
  $("#groups").change(function () {
    $("#join_group").attr("href", $(this).val());
  });
});